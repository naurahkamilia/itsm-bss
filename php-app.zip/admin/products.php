<?php
/**
 * Admin - Manage Products
 */

define('APP_ACCESS', true);
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Product.php';
require_once '../models/Category.php';

// Require admin access
Security::requireAdmin();

$currentPage = 'products';
$pageTitle = 'Kelola Produk - Admin Panel';

// Initialize models
$productModel = new Product();
$categoryModel = new Category();

// Get all categories for dropdown
$categories = $categoryModel->getAll();

// Get filter parameters
$filters = [
    'search' => $_GET['search'] ?? '',
    'category_id' => $_GET['category'] ?? null,
    'is_active' => isset($_GET['status']) ? ($_GET['status'] == 'active' ? 1 : 0) : null,
    'sort' => $_GET['sort'] ?? 'newest',
    'limit' => 50,
    'offset' => 0
];

// Get products
$products = $productModel->getAll($filters);
$totalProducts = $productModel->count($filters);

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="row mb-4">
        <div class="col">
            <h2>Kelola Produk</h2>
            <p class="text-muted">Tambah, edit, atau hapus produk di toko Anda</p>
        </div>
        <div class="col-auto">
            <a href="product-add.php" class="btn btn-gradient">
                <i class="bi bi-plus-circle me-2"></i>
                Tambah Produk Baru
            </a>
        </div>
    </div>

    <!-- Filters -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <!-- Search -->
                <div class="col-md-4">
                    <label class="form-label">Cari Produk</label>
                    <input type="text" 
                           name="search" 
                           class="form-control" 
                           placeholder="Nama produk..."
                           value="<?php echo htmlspecialchars($filters['search']); ?>">
                </div>
                
                <!-- Category Filter -->
                <div class="col-md-3">
                    <label class="form-label">Kategori</label>
                    <select name="category" class="form-select">
                        <option value="">Semua Kategori</option>
                        <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" 
                                <?php echo $filters['category_id'] == $category['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- Status Filter -->
                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="active" <?php echo ($_GET['status'] ?? '') == 'active' ? 'selected' : ''; ?>>
                            Aktif
                        </option>
                        <option value="inactive" <?php echo ($_GET['status'] ?? '') == 'inactive' ? 'selected' : ''; ?>>
                            Nonaktif
                        </option>
                    </select>
                </div>
                
                <!-- Sort -->
                <div class="col-md-2">
                    <label class="form-label">Urutkan</label>
                    <select name="sort" class="form-select">
                        <option value="newest" <?php echo $filters['sort'] == 'newest' ? 'selected' : ''; ?>>
                            Terbaru
                        </option>
                        <option value="name-asc" <?php echo $filters['sort'] == 'name-asc' ? 'selected' : ''; ?>>
                            Nama A-Z
                        </option>
                        <option value="price-low" <?php echo $filters['sort'] == 'price-low' ? 'selected' : ''; ?>>
                            Harga Terendah
                        </option>
                        <option value="price-high" <?php echo $filters['sort'] == 'price-high' ? 'selected' : ''; ?>>
                            Harga Tertinggi
                        </option>
                    </select>
                </div>
                
                <!-- Submit -->
                <div class="col-md-1">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-funnel"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Products Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-white py-3">
            <div class="row align-items-center">
                <div class="col">
                    <h5 class="mb-0">Daftar Produk (<?php echo $totalProducts; ?>)</h5>
                </div>
                <div class="col-auto">
                    <?php if (!empty($filters['search']) || !empty($filters['category_id']) || isset($_GET['status'])): ?>
                    <a href="products.php" class="btn btn-sm btn-outline-secondary">
                        <i class="bi bi-x-circle me-1"></i> Reset Filter
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <?php if (count($products) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="80">Gambar</th>
                            <th>Produk</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th width="100">Stok</th>
                            <th width="100">Status</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td>
                                <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                                     class="img-thumbnail"
                                     style="width: 60px; height: 60px; object-fit: cover;"
                                     onerror="this.src='<?php echo BASE_URL; ?>public/images/placeholder.jpg'">
                            </td>
                            <td>
                                <div class="fw-semibold"><?php echo htmlspecialchars($product['name']); ?></div>
                                <small class="text-muted">ID: <?php echo $product['id']; ?></small>
                            </td>
                            <td>
                                <span class="badge bg-info">
                                    <?php echo htmlspecialchars($product['category_name'] ?? '-'); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($product['discount_price']): ?>
                                <div class="text-success fw-semibold">
                                    Rp <?php echo number_format($product['discount_price'], 0, ',', '.'); ?>
                                </div>
                                <small class="text-muted text-decoration-line-through">
                                    Rp <?php echo number_format($product['price'], 0, ',', '.'); ?>
                                </small>
                                <?php else: ?>
                                <div>Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $product['stock'] > 0 ? 'bg-info' : 'bg-danger'; ?>">
                                    <?php echo $product['stock']; ?>
                                </span>
                            </td>
                            <td>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" 
                                           type="checkbox" 
                                           <?php echo $product['is_active'] ? 'checked' : ''; ?>
                                           onchange="if(confirm('Ubah status produk?')) window.location.href='product-toggle.php?id=<?php echo $product['id']; ?>'">
                                </div>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo BASE_URL; ?>product.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-info"
                                       title="Lihat"
                                       target="_blank">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="product-edit.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-primary"
                                       title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="product-delete.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-outline-danger"
                                       title="Hapus"
                                       onclick="return confirmDelete('<?php echo htmlspecialchars($product['name']); ?>')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-inbox display-1 text-muted"></i>
                <h5 class="mt-3">Tidak ada produk ditemukan</h5>
                <p class="text-muted">
                    <?php if (!empty($filters['search']) || !empty($filters['category_id']) || isset($_GET['status'])): ?>
                        Coba ubah filter pencarian Anda
                    <?php else: ?>
                        Mulai dengan menambahkan produk pertama
                    <?php endif; ?>
                </p>
                <a href="product-add.php" class="btn btn-gradient mt-2">
                    <i class="bi bi-plus-circle me-2"></i>
                    Tambah Produk
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
