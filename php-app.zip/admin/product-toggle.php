<?php
/**
 * Toggle Product Status
 */

define('APP_ACCESS', true);
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Product.php';

Security::requireAdmin();

$productId = $_GET['id'] ?? null;

if (!$productId) {
    $_SESSION['error_message'] = 'ID produk tidak valid';
    header('Location: products.php');
    exit;
}

$productModel = new Product();

if ($productModel->toggleActive($productId)) {
    $_SESSION['success_message'] = 'Status produk berhasil diubah';
} else {
    $_SESSION['error_message'] = 'Gagal mengubah status produk';
}

header('Location: products.php');
exit;
