<?php
/**
 * Delete Product
 */

define('APP_ACCESS', true);
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Product.php';

Security::requireAdmin();

$productId = $_GET['id'] ?? null;

if (!$productId) {
    $_SESSION['error_message'] = 'ID produk tidak valid';
    header('Location: products.php');
    exit;
}

$productModel = new Product();
$product = $productModel->getById($productId);

if (!$product) {
    $_SESSION['error_message'] = 'Produk tidak ditemukan';
    header('Location: products.php');
    exit;
}

if ($productModel->delete($productId)) {
    $_SESSION['success_message'] = 'Produk berhasil dihapus';
} else {
    $_SESSION['error_message'] = 'Gagal menghapus produk';
}

header('Location: products.php');
exit;
