<?php
/**
 * Edit Product
 */

define('APP_ACCESS', true);
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Product.php';
require_once '../models/Category.php';

Security::requireAdmin();

$productId = $_GET['id'] ?? null;
if (!$productId) {
    header('Location: products.php');
    exit;
}

$productModel = new Product();
$product = $productModel->getById($productId);

if (!$product) {
    $_SESSION['error_message'] = 'Produk tidak ditemukan';
    header('Location: products.php');
    exit;
}

$currentPage = 'products';
$pageTitle = 'Edit Produk - Admin Panel';

$categoryModel = new Category();
$categories = $categoryModel->getAll();

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="products.php">Produk</a></li>
                    <li class="breadcrumb-item active">Edit: <?php echo htmlspecialchars($product['name']); ?></li>
                </ol>
            </nav>

            <div class="card shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0">
                        <i class="bi bi-pencil me-2"></i>
                        Edit Produk: <?php echo htmlspecialchars($product['name']); ?>
                    </h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        <strong>Info:</strong> Untuk mengedit produk, silakan gunakan phpMyAdmin atau edit langsung di database.
                    </div>

                    <!-- Product Info -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 class="img-fluid rounded"
                                 onerror="this.src='<?php echo BASE_URL; ?>public/images/placeholder.jpg'">
                        </div>
                        <div class="col-md-8">
                            <table class="table">
                                <tr>
                                    <th width="150">ID</th>
                                    <td><?php echo $product['id']; ?></td>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                                </tr>
                                <tr>
                                    <th>Kategori</th>
                                    <td><?php echo htmlspecialchars($product['category_name'] ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <th>Harga</th>
                                    <td>Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></td>
                                </tr>
                                <?php if ($product['discount_price']): ?>
                                <tr>
                                    <th>Harga Diskon</th>
                                    <td class="text-success">Rp <?php echo number_format($product['discount_price'], 0, ',', '.'); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <th>Stok</th>
                                    <td><?php echo $product['stock']; ?> unit</td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <span class="badge <?php echo $product['is_active'] ? 'bg-success' : 'bg-secondary'; ?>">
                                            <?php echo $product['is_active'] ? 'Aktif' : 'Nonaktif'; ?>
                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <h6 class="mb-3">Edit via phpMyAdmin:</h6>
                    <ol>
                        <li class="mb-2">Buka phpMyAdmin</li>
                        <li class="mb-2">Pilih database <code>toko_online</code></li>
                        <li class="mb-2">Klik tabel <code>products</code></li>
                        <li class="mb-2">Cari produk dengan ID: <strong><?php echo $product['id']; ?></strong></li>
                        <li class="mb-2">Klik <strong>Edit</strong></li>
                        <li class="mb-2">Ubah data yang diperlukan dan <strong>Save</strong></li>
                    </ol>

                    <div class="mt-4">
                        <a href="products.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left me-2"></i>
                            Kembali
                        </a>
                        <a href="http://localhost/phpmyadmin" class="btn btn-primary" target="_blank">
                            <i class="bi bi-database me-2"></i>
                            Buka phpMyAdmin
                        </a>
                        <a href="<?php echo BASE_URL; ?>product.php?id=<?php echo $product['id']; ?>" 
                           class="btn btn-outline-info" 
                           target="_blank">
                            <i class="bi bi-eye me-2"></i>
                            Lihat Produk
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
