<?php
/**
 * Add New Product
 */

define('APP_ACCESS', true);
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Product.php';
require_once '../models/Category.php';

Security::requireAdmin();

$currentPage = 'products';
$pageTitle = 'Tambah Produk - Admin Panel';

$categoryModel = new Category();
$categories = $categoryModel->getAll();

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="products.php">Produk</a></li>
                    <li class="breadcrumb-item active">Tambah Produk</li>
                </ol>
            </nav>

            <div class="card shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0">
                        <i class="bi bi-plus-circle me-2"></i>
                        Tambah Produk Baru
                    </h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        <strong>Info:</strong> Fitur menambah produk memerlukan implementasi lengkap dengan upload gambar. 
                        Untuk sementara, silakan tambah produk langsung melalui database atau gunakan migration.sql yang sudah ada.
                    </div>

                    <h6 class="mb-3">Cara Menambah Produk:</h6>
                    <ol>
                        <li class="mb-2">Buka <strong>phpMyAdmin</strong></li>
                        <li class="mb-2">Pilih database <strong>toko_online</strong></li>
                        <li class="mb-2">Klik tabel <strong>products</strong></li>
                        <li class="mb-2">Klik tab <strong>Insert</strong></li>
                        <li class="mb-2">Isi data produk dengan format:
                            <ul>
                                <li><strong>category_id:</strong> ID kategori (1-6)</li>
                                <li><strong>name:</strong> Nama produk</li>
                                <li><strong>description:</strong> Deskripsi produk</li>
                                <li><strong>price:</strong> Harga normal</li>
                                <li><strong>discount_price:</strong> Harga diskon (opsional)</li>
                                <li><strong>stock:</strong> Jumlah stok</li>
                                <li><strong>is_active:</strong> 1 = Aktif, 0 = Nonaktif</li>
                                <li><strong>image:</strong> URL gambar dari Unsplash/internet</li>
                            </ul>
                        </li>
                    </ol>

                    <div class="alert alert-warning mt-3">
                        <i class="bi bi-lightbulb me-2"></i>
                        <strong>Tips Gambar:</strong> Gunakan gambar dari Unsplash.com dengan format:
                        <br><code>https://images.unsplash.com/photo-xxxxx?w=800</code>
                    </div>

                    <div class="mt-4">
                        <a href="products.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left me-2"></i>
                            Kembali ke Daftar Produk
                        </a>
                        <a href="http://localhost/phpmyadmin" class="btn btn-primary" target="_blank">
                            <i class="bi bi-database me-2"></i>
                            Buka phpMyAdmin
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
