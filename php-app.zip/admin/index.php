<?php
/**
 * Admin Dashboard
 */

define('APP_ACCESS', true);
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Product.php';
require_once '../models/Category.php';
require_once '../models/User.php';

// Require admin access
Security::requireAdmin();

$currentPage = 'dashboard';
$pageTitle = 'Dashboard - Admin Panel';

// Get statistics
$productModel = new Product();
$categoryModel = new Category();

$totalProducts = $productModel->count([]);
$activeProducts = $productModel->count(['is_active' => 1]);
$inactiveProducts = $totalProducts - $activeProducts;
$totalCategories = count($categoryModel->getAll());

// Get recent products
$recentProducts = $productModel->getAll(['limit' => 5, 'offset' => 0]);

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <!-- Welcome Message -->
    <div class="row mb-4">
        <div class="col-12">
            <h2>Selamat Datang, <?php echo htmlspecialchars($_SESSION['user_name']); ?>! 👋</h2>
            <p class="text-muted">Berikut adalah ringkasan toko Anda</p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <!-- Total Products -->
        <div class="col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-primary bg-opacity-10 p-3 rounded">
                                <i class="bi bi-box-seam text-primary fs-2"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">Total Produk</h6>
                            <h3 class="mb-0"><?php echo $totalProducts; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <a href="products.php" class="text-decoration-none small">
                        Lihat semua <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Active Products -->
        <div class="col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-success bg-opacity-10 p-3 rounded">
                                <i class="bi bi-check-circle text-success fs-2"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">Produk Aktif</h6>
                            <h3 class="mb-0"><?php echo $activeProducts; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <a href="products.php?status=active" class="text-decoration-none small">
                        Kelola produk <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Inactive Products -->
        <div class="col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-warning bg-opacity-10 p-3 rounded">
                                <i class="bi bi-exclamation-circle text-warning fs-2"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">Produk Nonaktif</h6>
                            <h3 class="mb-0"><?php echo $inactiveProducts; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <a href="products.php?status=inactive" class="text-decoration-none small">
                        Lihat detail <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Total Categories -->
        <div class="col-md-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="bg-info bg-opacity-10 p-3 rounded">
                                <i class="bi bi-grid-3x3 text-info fs-2"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="text-muted mb-1">Kategori</h6>
                            <h3 class="mb-0"><?php echo $totalCategories; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0">
                    <a href="categories.php" class="text-decoration-none small">
                        Kelola kategori <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-3">
                        <i class="bi bi-lightning-fill text-warning me-2"></i>
                        Quick Actions
                    </h5>
                    <div class="row g-2">
                        <div class="col-md-3">
                            <a href="products.php?action=add" class="btn btn-gradient w-100">
                                <i class="bi bi-plus-circle me-2"></i>
                                Tambah Produk
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="categories.php?action=add" class="btn btn-outline-primary w-100">
                                <i class="bi bi-folder-plus me-2"></i>
                                Tambah Kategori
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="products.php" class="btn btn-outline-success w-100">
                                <i class="bi bi-list-ul me-2"></i>
                                Lihat Semua Produk
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo BASE_URL; ?>" class="btn btn-outline-info w-100" target="_blank">
                                <i class="bi bi-eye me-2"></i>
                                Lihat Toko
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Products -->
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="mb-0">
                        <i class="bi bi-clock-history me-2"></i>
                        Produk Terbaru
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php if (count($recentProducts) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="80">Gambar</th>
                                    <th>Nama Produk</th>
                                    <th>Kategori</th>
                                    <th>Harga</th>
                                    <th>Stok</th>
                                    <th width="100">Status</th>
                                    <th width="120">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentProducts as $product): ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                             alt="<?php echo htmlspecialchars($product['name']); ?>"
                                             class="img-thumbnail"
                                             style="width: 60px; height: 60px; object-fit: cover;"
                                             onerror="this.src='<?php echo BASE_URL; ?>public/images/placeholder.jpg'">
                                    </td>
                                    <td>
                                        <div class="fw-semibold"><?php echo htmlspecialchars($product['name']); ?></div>
                                        <small class="text-muted">ID: <?php echo $product['id']; ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($product['category_name'] ?? '-'); ?></td>
                                    <td>
                                        <?php if ($product['discount_price']): ?>
                                        <div class="text-success fw-semibold">
                                            Rp <?php echo number_format($product['discount_price'], 0, ',', '.'); ?>
                                        </div>
                                        <small class="text-muted text-decoration-line-through">
                                            Rp <?php echo number_format($product['price'], 0, ',', '.'); ?>
                                        </small>
                                        <?php else: ?>
                                        <div class="fw-semibold">
                                            Rp <?php echo number_format($product['price'], 0, ',', '.'); ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $product['stock'] > 0 ? 'bg-info' : 'bg-danger'; ?>">
                                            <?php echo $product['stock']; ?> unit
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $product['is_active'] ? 'bg-success' : 'bg-secondary'; ?>">
                                            <?php echo $product['is_active'] ? 'Aktif' : 'Nonaktif'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="products.php?action=edit&id=<?php echo $product['id']; ?>" 
                                           class="btn btn-sm btn-outline-primary"
                                           title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="<?php echo BASE_URL; ?>product.php?id=<?php echo $product['id']; ?>" 
                                           class="btn btn-sm btn-outline-info"
                                           title="Lihat"
                                           target="_blank">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-inbox display-1 text-muted"></i>
                        <h5 class="mt-3">Belum ada produk</h5>
                        <p class="text-muted">Mulai dengan menambahkan produk pertama Anda</p>
                        <a href="products.php?action=add" class="btn btn-gradient">
                            <i class="bi bi-plus-circle me-2"></i>
                            Tambah Produk
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
