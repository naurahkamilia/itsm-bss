<?php
/**
 * Logout Script
 */

define('APP_ACCESS', true);
require_once 'config/config.php';

// Destroy session
session_unset();
session_destroy();

// Redirect to home
header('Location: ' . BASE_URL);
exit;
