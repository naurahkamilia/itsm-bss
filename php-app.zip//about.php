<?php
/**
 * About Page
 */

define('APP_ACCESS', true);
require_once 'config/config.php';
require_once 'config/database.php';

$currentPage = 'about';
$pageTitle = 'Tentang Toko - ' . APP_NAME;

include 'includes/header.php';
?>

<main class="py-5">
    <div class="container">
        <!-- Header -->
        <div class="text-center mb-5">
            <h1 class="mb-2">Tentang Kami</h1>
            <p class="text-muted">Kenali lebih dekat Toko Online Hijau</p>
        </div>

        <div class="row g-4">
            <!-- About Content -->
            <div class="col-lg-8 mx-auto">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body p-4">
                        <div class="text-center mb-4">
                            <div class="bg-gradient-to-br p-4 rounded-circle d-inline-flex mb-3" 
                                 style="background: linear-gradient(135deg, var(--primary-green) 0%, var(--primary-blue) 100%);">
                                <i class="bi bi-shop fs-1 text-white"></i>
                            </div>
                        </div>

                        <h3 class="text-center mb-4">Selamat Datang di <?php echo APP_NAME; ?></h3>
                        
                        <p class="text-muted mb-3">
                            <strong><?php echo APP_NAME; ?></strong> adalah platform e-commerce yang menyediakan berbagai produk berkualitas dengan harga terjangkau. 
                            Kami berkomitmen untuk memberikan pengalaman belanja online yang mudah, cepat, dan terpercaya.
                        </p>

                        <p class="text-muted mb-3">
                            Dengan koleksi produk yang terus berkembang dan pelayanan customer service yang responsif, 
                            kami siap membantu Anda menemukan produk yang Anda cari.
                        </p>

                        <hr class="my-4">

                        <h5 class="mb-3">Mengapa Berbelanja di Toko Online Hijau?</h5>
                        
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="bg-success bg-opacity-10 p-3 rounded me-3">
                                        <i class="bi bi-shield-check text-success fs-4"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Produk Berkualitas</h6>
                                        <p class="text-muted small mb-0">Semua produk dijamin original dan berkualitas tinggi</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="bg-primary bg-opacity-10 p-3 rounded me-3">
                                        <i class="bi bi-truck text-primary fs-4"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Pengiriman Cepat</h6>
                                        <p class="text-muted small mb-0">Pesanan Anda akan diproses dengan cepat</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="bg-success bg-opacity-10 p-3 rounded me-3">
                                        <i class="bi bi-cash-coin text-success fs-4"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Harga Terjangkau</h6>
                                        <p class="text-muted small mb-0">Dapatkan penawaran terbaik dengan harga kompetitif</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="d-flex align-items-start">
                                    <div class="bg-primary bg-opacity-10 p-3 rounded me-3">
                                        <i class="bi bi-headset text-primary fs-4"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1">Customer Service 24/7</h6>
                                        <p class="text-muted small mb-0">Tim kami siap membantu Anda kapan saja</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <div class="text-center">
                            <h5 class="mb-3">Hubungi Kami</h5>
                            <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>" 
                               class="btn btn-gradient btn-lg"
                               target="_blank">
                                <i class="bi bi-whatsapp me-2"></i>
                                Chat via WhatsApp
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Stats -->
                <div class="row g-3 text-center">
                    <div class="col-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-body">
                                <i class="bi bi-box-seam text-success fs-2 mb-2"></i>
                                <h4 class="mb-0">1000+</h4>
                                <small class="text-muted">Produk</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-body">
                                <i class="bi bi-people text-primary fs-2 mb-2"></i>
                                <h4 class="mb-0">5000+</h4>
                                <small class="text-muted">Pelanggan</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-body">
                                <i class="bi bi-star-fill text-warning fs-2 mb-2"></i>
                                <h4 class="mb-0">4.8</h4>
                                <small class="text-muted">Rating</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- WhatsApp Float Button -->
<a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>?text=<?php echo urlencode('Halo Toko Online Hijau, saya ingin bertanya.'); ?>" 
   class="whatsapp-float" 
   target="_blank"
   title="Chat via WhatsApp">
    <i class="bi bi-whatsapp"></i>
</a>

<?php include 'includes/footer.php'; ?>
