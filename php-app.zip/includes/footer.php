    <!-- Footer -->
    <footer class="bg-dark text-white mt-5 py-4">
        <div class="container">
            <div class="row g-4">
                <!-- About -->
                <div class="col-md-4">
                    <h5 class="mb-3">
                        <i class="bi bi-shop me-2"></i>
                        <?php echo APP_NAME; ?>
                    </h5>
                    <p class="text-white-50">
                        Platform e-commerce terpercaya untuk kebutuhan belanja online Anda. 
                        Produk berkualitas dengan harga terjangkau.
                    </p>
                    <div class="d-flex gap-2">
                        <a href="https://wa.me/<?php echo WHATSAPP_NUMBER; ?>" 
                           class="btn btn-outline-light btn-sm" 
                           target="_blank">
                            <i class="bi bi-whatsapp"></i>
                        </a>
                        <a href="mailto:info@tokoonline.com" 
                           class="btn btn-outline-light btn-sm">
                            <i class="bi bi-envelope"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="col-md-4">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="<?php echo BASE_URL; ?>" class="text-white-50 text-decoration-none">
                                <i class="bi bi-chevron-right me-1"></i> Produk
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo BASE_URL; ?>categories.php" class="text-white-50 text-decoration-none">
                                <i class="bi bi-chevron-right me-1"></i> Kategori
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo BASE_URL; ?>about.php" class="text-white-50 text-decoration-none">
                                <i class="bi bi-chevron-right me-1"></i> Tentang Toko
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="<?php echo BASE_URL; ?>contact.php" class="text-white-50 text-decoration-none">
                                <i class="bi bi-chevron-right me-1"></i> Kontak
                            </a>
                        </li>
                    </ul>
                </div>
                
                <!-- Contact Info -->
                <div class="col-md-4">
                    <h5 class="mb-3">Hubungi Kami</h5>
                    <ul class="list-unstyled text-white-50">
                        <li class="mb-2">
                            <i class="bi bi-whatsapp me-2"></i>
                            +<?php echo WHATSAPP_NUMBER; ?>
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-envelope me-2"></i>
                            info@tokoonline.com
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-geo-alt me-2"></i>
                            Jakarta, Indonesia
                        </li>
                        <li class="mb-2">
                            <i class="bi bi-clock me-2"></i>
                            Senin - Sabtu: 08:00 - 17:00
                        </li>
                    </ul>
                </div>
            </div>
            
            <hr class="border-secondary my-4">
            
            <!-- Copyright -->
            <div class="text-center text-white-50">
                <small>
                    &copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved. 
                    | Version <?php echo APP_VERSION; ?>
                    <?php if (APP_ENV === 'development'): ?>
                        <span class="badge bg-warning text-dark ms-2">Development Mode</span>
                    <?php endif; ?>
                </small>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="<?php echo BASE_URL; ?>public/js/script.js"></script>
    
    <?php if (isset($_SESSION['success_message'])): ?>
    <script>
        // Show success message
        alert('<?php echo addslashes($_SESSION['success_message']); ?>');
    </script>
    <?php 
        unset($_SESSION['success_message']);
    endif; 
    ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
    <script>
        // Show error message
        alert('<?php echo addslashes($_SESSION['error_message']); ?>');
    </script>
    <?php 
        unset($_SESSION['error_message']);
    endif; 
    ?>
</body>
</html>
